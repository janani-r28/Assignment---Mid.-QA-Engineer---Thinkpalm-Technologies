# httpbin-test-framework

Pytest-based test framework for testing https://httpbin.org

## Features
- YAML configuration support (`config/config.yaml`)
- Custom retry decorator with detailed logging
- Faker-based randomized test data utilities
- Allure reporting (results saved to `reports/allure-results`)
- pytest-html fallback HTML report
- RabbitMQ messaging integration (optional, covered in Docker)
- Docker Compose to spin up httpbin + RabbitMQ + Prometheus/Grafana (optional)
- Prometheus metrics example with a custom counter for retries

## Repo layout
```
httpbin-test-framework/
├── README.md
├── requirements.txt
├── pytest.ini
├── pyproject.toml
├── .github/
│   └── workflows/ci.yml
├── config/
│   └── config.yaml
├── tests/
│   ├── conftest.py
│   ├── test_response_formats.py
│   ├── test_request_inspection.py
│   ├── test_dynamic_data.py
│   └── test_rabbitmq_messaging.py
├── utils/
│   ├── retry_decorator.py
│   ├── faker_utils.py
│   └── http_client.py
├── docker/
│   ├── docker-compose.yml
│   └── test-runner.Dockerfile
└── ci/
    └── prometheus/
        └── prometheus.yml
```

## Setup (local)

1. Create virtualenv and install deps
```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

2. Run tests
```bash
pytest -q
```

3. Generate and view Allure report (requires allure CLI installed)
```bash
pytest --alluredir=reports/allure-results
allure serve reports/allure-results
```

4. Generate HTML report
```bash
pytest --html=reports/report.html
```

## Docker Compose (optional)
Spin up services (httpbin, rabbitmq, prometheus, grafana) and then run tests in container:
```bash
cd docker
docker-compose up --build
# in another shell:
docker-compose exec test-runner pytest --maxfail=1 -q
```

## CI
GitHub Actions workflow is provided at `.github/workflows/ci.yml`. It runs pytest and uploads Allure results as artifacts.

## Notes
- Pin dependency versions are in `requirements.txt`.
- For local RabbitMQ tests, ensure `config/config.yaml` uses `localhost` if running RabbitMQ locally.
- Prometheus in this repo is optional and can be enabled via `config/config.yaml`.
