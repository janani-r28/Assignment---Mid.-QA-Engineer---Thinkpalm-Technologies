from functools import wraps
import time
from loguru import logger

def retry(attempts=3, backoff_seconds=1, allowed_exceptions=(Exception,)):
    """Custom retry decorator with detailed logging for each attempt."""
    def decorator(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            last_exc = None
            for attempt in range(1, attempts + 1):
                start = time.time()
                try:
                    logger.info(f"[retry] Attempt {attempt}/{attempts} for {fn.__name__}")
                    result = fn(*args, **kwargs)
                    elapsed = time.time() - start
                    logger.info(f"[retry] Success on attempt {attempt} for {fn.__name__} (elapsed: {elapsed:.3f}s)")
                    return result
                except allowed_exceptions as e:
                    elapsed = time.time() - start
                    last_exc = e
                    logger.warning(f"[retry] Exception on attempt {attempt} for {fn.__name__}: {e} (elapsed: {elapsed:.3f}s)")
                    if attempt < attempts:
                        backoff = backoff_seconds * (2 ** (attempt - 1))
                        logger.info(f"[retry] Backing off {backoff}s before next attempt")
                        time.sleep(backoff)
            logger.error(f"[retry] All {attempts} attempts failed for {fn.__name__}: {last_exc}")
            raise last_exc
        return wrapper
    return decorator
