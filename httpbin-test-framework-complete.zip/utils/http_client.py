import yaml
from pathlib import Path

_config = None

def load_config():
    global _config
    if _config is None:
        conf_path = Path(__file__).parents[1] / "config" / "config.yaml"
        with open(conf_path) as f:
            _config = yaml.safe_load(f)
    return _config

def base_url():
    return load_config()["base_url"].rstrip("/")

def default_timeout():
    return load_config().get("timeout", 10)
