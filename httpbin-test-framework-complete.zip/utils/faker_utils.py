from faker import Faker
fake = Faker()

def random_user_payload():
    return {
        "name": fake.name(),
        "email": fake.email(),
        "address": {
            "street": fake.street_address(),
            "city": fake.city(),
            "country": fake.country()
        },
        "bio": fake.sentence(nb_words=12)
    }

def random_query_params():
    return {
        "search": fake.word(),
        "page": fake.random_int(min=1, max=50),
        "size": fake.random_element(elements=(10, 20, 50))
    }
