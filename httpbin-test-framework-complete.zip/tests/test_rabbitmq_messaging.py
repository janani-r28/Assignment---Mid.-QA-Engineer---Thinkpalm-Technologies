import pytest
import pika
import uuid
import json
import time
from utils.http_client import load_config
import allure

@pytest.mark.integration
@allure.title("Publish message to RabbitMQ and consume it")
def test_rabbitmq_publish_consume():
    cfg = load_config()["rabbitmq"]
    creds = pika.PlainCredentials("guest", "guest")
    parameters = pika.ConnectionParameters(host=cfg["host"], port=cfg["port"], credentials=creds, heartbeat=0)
    connection = pika.BlockingConnection(parameters)
    channel = connection.channel()
    queue = cfg["queue"]
    channel.queue_declare(queue=queue, durable=False, auto_delete=True)

    payload = {"id": str(uuid.uuid4()), "payload": "hello from test"}
    channel.basic_publish(exchange="", routing_key=queue, body=json.dumps(payload))

    method_frame, header_frame, body = channel.basic_get(queue=queue, auto_ack=True)
    start = time.time()
    while method_frame is None and time.time() - start < 5:
        time.sleep(0.2)
        method_frame, header_frame, body = channel.basic_get(queue=queue, auto_ack=True)

    connection.close()

    assert method_frame is not None, "Did not receive message from RabbitMQ"
    got = json.loads(body)
    assert got["id"] == payload["id"]
