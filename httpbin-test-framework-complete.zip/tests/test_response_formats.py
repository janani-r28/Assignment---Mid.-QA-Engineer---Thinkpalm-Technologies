import pytest
import allure

@allure.title("GET /json returns JSON structure")
def test_get_json(client):
    r = client.get("/json")
    assert r.status_code == 200
    data = r.json()
    assert isinstance(data, dict)
    assert "slideshow" in data

@allure.title("GET /xml returns well-formed XML (as text)")
def test_get_xml(client):
    r = client.get("/xml")
    assert r.status_code == 200
    assert r.text.strip().startswith("<?xml")

@allure.title("GET /html returns HTML content")
def test_get_html(client):
    r = client.get("/html")
    assert r.status_code == 200
    assert "<html" in r.text.lower()

@allure.title("Test various status codes")
@pytest.mark.parametrize("code", [200, 201, 204, 404, 418])
def test_status_codes(client, code):
    r = client.get(f"/status/{code}")
    assert r.status_code == code
