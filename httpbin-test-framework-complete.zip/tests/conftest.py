import pytest
from utils.http_client import base_url, default_timeout, load_config
import requests
from prometheus_client import start_http_server, Counter
import threading
import time

# example metric to count retries
retry_counter = Counter('test_retries_total', 'Total number of retries performed by tests')

@pytest.fixture(scope="session")
def config():
    return load_config()

@pytest.fixture
def client():
    class _Client:
        def get(self, path, **kwargs):
            url = f"{base_url()}{path}"
            return requests.get(url, timeout=default_timeout(), **kwargs)
        def post(self, path, **kwargs):
            url = f"{base_url()}{path}"
            return requests.post(url, timeout=default_timeout(), **kwargs)
    return _Client()

# Optional: start a prometheus metrics server for tests if enabled
@pytest.fixture(scope="session", autouse=True)
def prometheus_server(config):
    if config.get("prometheus", {}).get("enabled", False):
        port = config["prometheus"].get("port", 9000)
        t = threading.Thread(target=start_http_server, args=(port,), daemon=True)
        t.start()
        time.sleep(0.5)
        yield
    else:
        yield
