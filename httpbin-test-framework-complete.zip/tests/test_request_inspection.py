import pytest
from utils.faker_utils import random_user_payload, random_query_params
from utils.retry_decorator import retry
import allure

@allure.title("POST /post echoes json body and headers")
def test_post_echo_json(client):
    payload = random_user_payload()
    headers = {"X-Test-Tag": "qa-assignment"}
    r = client.post("/post", json=payload, headers=headers)
    assert r.status_code == 200
    body = r.json()
    assert body["json"] == payload
    # httpbin returns headers as dict, check presence of our header
    assert any('X-Test-Tag' in k for k in body.get('headers', {}).keys())

@allure.title("GET /get echoes query params")
def test_get_echo_query(client):
    params = random_query_params()
    r = client.get("/get", params=params)
    assert r.status_code == 200
    body = r.json()
    assert body["args"] == {k: str(v) for k, v in params.items()}

@allure.title("Retry wrapper works for flaky endpoint")
def test_retry_wrapper(client):
    @retry(attempts=3, backoff_seconds=1, allowed_exceptions=(Exception,))
    def call_delay():
        r = client.get("/delay/1", timeout=5)
        if r.status_code != 200:
            raise RuntimeError("Not 200")
        return r
    r = call_delay()
    assert r.status_code == 200
