import allure
from utils.faker_utils import random_user_payload

@allure.title("POST /post with randomized payload contains fingerprint and timestamp")
def test_dynamic_payload_has_fields(client):
    payload = random_user_payload()
    from datetime import datetime
    import uuid
    payload["run_ts"] = datetime.utcnow().isoformat()
    payload["run_id"] = str(uuid.uuid4())
    r = client.post("/post", json=payload)
    assert r.status_code == 200
    body = r.json()
    assert body["json"]["run_id"] == payload["run_id"]
